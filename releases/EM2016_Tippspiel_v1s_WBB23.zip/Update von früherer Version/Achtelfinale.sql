UPDATE bb1_em2016_spiele SET team_1_id = '4', team_2_id = '11' WHERE gameid = '37';
UPDATE bb1_em2016_spiele SET team_1_id = '7', team_2_id = '12' WHERE gameid = '38';
UPDATE bb1_em2016_spiele SET team_1_id = '16', team_2_id = '21' WHERE gameid = '39';
UPDATE bb1_em2016_spiele SET team_1_id = '1', team_2_id = '19' WHERE gameid = '40';
UPDATE bb1_em2016_spiele SET team_1_id = '9', team_2_id = '8' WHERE gameid = '41';
UPDATE bb1_em2016_spiele SET team_1_id = '24', team_2_id = '17' WHERE gameid = '42';
UPDATE bb1_em2016_spiele SET team_1_id = '18', team_2_id = '13' WHERE gameid = '43';
UPDATE bb1_em2016_spiele SET team_1_id = '5', team_2_id = '22' WHERE gameid = '44';